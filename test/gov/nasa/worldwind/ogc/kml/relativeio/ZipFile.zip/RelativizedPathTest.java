package gov.nasa.worldwind.ogc.kml.relativeio;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class RelativizedPathTest
{
	@Before
	public void setUp() throws Exception
	{
	}

	@After
	public void tearDown() throws Exception
	{
	}

	@Test
	public void testRelativizePath()
	{
		/*
		 * Example:
		 * - dir/sydney.kmz contains model/model.kml
		 * - model/model.kml points to ../icon/pin.png
		 * = should resolve to dir/sydney.kmz/icon/pin.png (dir/sydney.kmz/model/../icon/pin.png)
		 * = so sydney.kmz doc should return its icon/pin.png
		 * 
		 * Example 2:
		 * - dir/sydney.kmz contains model/model.kml
		 * - model/model.kml points to ../../icon/pin.png
		 * = should resolve to dir/icon/pin.png (dir/sydney.kmz/model/../../icon/pin.png)
		 * = so sydney.kmz doc should return the dir/icon/pin.png path
		 * 
		 * Example 3:
		 * - dir1/dir2/sydney.kmz contains dir3/dir4/melbourne.kmz
		 * - dir3/dir4/melbourne.kmz contains model/model.kml
		 * - model/model.kml points to ../icon/pin.png
		 * = should resolve to dir1/dir2/sydney.kmz/dir3/dir4/melbourne.kmz/icon/pin.png (dir1/dir2/sydney.kmz/dir3/dir4/melbourne.kmz/model/../icon/pin.png)
		 * = so melbourne.kmz doc should return its icon/pin.png
		 * 
		 * Example 4:
		 * - dir1/dir2/sydney.kmz contains dir3/dir4/melbourne.kmz
		 * - dir3/dir4/melbourne.kmz contains model/model.kml
		 * - model/model.kml points to ../../../../icon/pin.png
		 * = should resolve to dir1/dir2/sydney.kmz/icon/pin.png (dir1/dir2/sydney.kmz/dir3/dir4/melbourne.kmz/model/../../../../icon/pin.png)
		 * = so sydney.kmz doc should return its icon/pin.png
		 * 
		 * Example 5:
		 * - dir1/dir2/sydney.kmz contains dir3/dir4/melbourne.kmz
		 * - dir3/dir4/melbourne.kmz contains model/model.kml
		 * - model/model.kml points to ../../../../../../icon/pin.png
		 * = should resolve to dir1/icon/pin.png (dir1/dir2/sydney.kmz/dir3/dir4/melbourne.kmz/model/../../../../../../icon/pin.png)
		 * = so sydney.kmz doc should return the dir1/icon/pin.png path
		 */
		
		
	}

	@Test
	public void testNormalizePath()
	{
		fail("Not yet implemented");
	}

}
